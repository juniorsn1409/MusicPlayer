import 'package:flutter/material.dart';

import 'pages/firstpag.dart';

void main() {
  runApp(const MyApp());
}
